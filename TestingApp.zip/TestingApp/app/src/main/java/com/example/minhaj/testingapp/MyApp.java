package com.example.minhaj.testingapp;

import android.app.Application;

/**
 * Created by minhaj on 3/6/2017.
 */
public class MyApp extends Application{
        static String serverURL = "http://104.238.93.150/~appdevelopment/family_tracker/";
        String lat;
        String lng; static String resigterUser = "register_user.php";
        static String loginUser = "login_user.php";
        static String listAll = "get_all_user.php";
        static String updateLoc = "update_user.php";

        String nameOfLoginUser;

        String UserId;

        public MyApp() {}

    public String getUserId()
    {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public String getNameOfLoginUser() {
        return nameOfLoginUser;
    }

    public void setNameOfLoginUser(String nameOfLoginUser) {
        this.nameOfLoginUser = nameOfLoginUser;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }
}
