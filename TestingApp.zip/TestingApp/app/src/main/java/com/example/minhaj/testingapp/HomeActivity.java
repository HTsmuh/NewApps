package com.example.minhaj.testingapp;

import android.location.Location;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class HomeActivity extends FragmentActivity {
    private ArrayList<String> menuList;
    private ImageView msgbtn;
    private  ImageView menuclick;
    private TextView headername;
    String selectedSub;
    private String[] menu;
    int clIDLenght;
    int integerNumber;
    private  Integer []menuIcons;
    private DrawerLayout dLayout;
    private ImageView useronclick,sendsms;
    private ListView dList;
    private MyApp objects;

    final int RQS_GooglePlayServices = 1;
    private GoogleMap myMap;
    private GoogleMap googleMap;
    double latitude = 	25.3176532;
    double longitude = 82.9739064;

    Location myLocation;
    double gkplatitude=26.7588	;
    double gkplongitude=83.3697 ;
    double deoslatitude=26.5000;
    double deoslongitude=83.7900 ;
    //TextView tvLocInfo;
    GPSTracker gps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
