package com.example.minhaj.testingapp;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;


public class SignupActivity extends Activity {

    private TextView tv;
    private PendingIntent tracking;
    private AlarmManager alarms;
    SimpleCursorAdapter adapter;
    private long UPDATE_INTERVAL = 30000L;
    private int START_DELAY = 5;
    private String DEBUG_TAG = "LocationServiceActivity";
    Button loginbtn;
    Spinner selecteFamily;
    SQLiteDatabase db;
    String[] loginType = { "Select", "Family Member", "Fiends", "Sisters", "Brothers" };
    String userType;
    Spinner user;
    EditText etname;
    EditText etaddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        gps = new GPSTracker(this);
        obj = ((MyApp)getApplicationContext());
        etname = ((EditText)findViewById(R.id.etname));
        etaddress = ((EditText)findViewById(R.id.etaddress));
        etpin = ((EditText)findViewById(R.id.etpin));
        etusename = ((EditText)findViewById(R.id.etusername));
        etpass = ((EditText)findViewById(R.id.pass));
        alarms = ((AlarmManager)getSystemService("alarm"));
        selecteFamily = ((Spinner)findViewById(R.id.usertype));
        loginbtn = ((Button)findViewById(R.id.signupbtn));
        user = ((Spinner)findViewById(R.id.usertype));
        user.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter aa = new ArrayAdapter(this, R.layout.activity_signup, loginType);
        aa.setDropDownViewResource(17367049);

        selecteFamily.setAdapter(aa);
        loginbtn.setOnClickListener(new SignupActivtiy.2(this));


        setRecurringAlarm(getBaseContext());
        CreateDataBaseSQlite();
    }


    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(2131427328, menu);
        return true;
    }

    EditText etpin;
    EditText etusename;
    EditText etpass;
    MyApp obj;
    GPSTracker gps;
    public boolean onOptionsItemSelected(MenuItem item) { int id = item.getItemId();
        if (id == 2131165235) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void CreateDataBaseSQlite()
    {
        db = openOrCreateDatabase("FamilyTracker", 0, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS member(name VARCHAR,address VARCHAR,username VARCHAR,password,VARCHAR,usertype VARCHAR,pin VARCHAR,lat VARCHAR,lng VARCHAR);");
    }

    public void RegisterUser(String name, String addres, String pin, String usertype, String usename, String password, String lat, String lng)
    {
        try {
            db.execSQL("INSERT INTO member VALUES('" + name + "','" +
                    addres + "','" + pin + "','" + usertype + "','" + usename + "','" + password + "','" + lat + "','" + lng + "');");
            Toast.makeText(this, "SignUp Successfully", 1).show();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setRecurringAlarm(Context context)
    {
        Calendar cal = Calendar.getInstance();

        cal.add(13, START_DELAY);

        Intent intent = new Intent(context, AlarmReceiver.class);

        tracking = PendingIntent.getBroadcast(context, 0, intent, 268435456);

        alarms.setInexactRepeating(0, cal.getTimeInMillis(), UPDATE_INTERVAL, tracking);

    }
}
