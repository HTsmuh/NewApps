package com.example.madeel.devicetracker;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.LocationManager;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;

public class login extends AppCompatActivity {
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    TextView f17t;
    TextView t2;

    class C01871 implements OnClickListener {
        C01871() {
        }

        public void onClick(DialogInterface dialog, int which) {
            login.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        }
    }

    public class AsyncRetrieve2 extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        ProgressDialog pdLoading = new ProgressDialog(login.this);
        String res;
        String f4u;
        URL url = null;

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... params) {
            try {
                this.url = new URL(this.f4u);
                try {
                    this.conn = (HttpURLConnection) this.url.openConnection();
                    this.conn.setReadTimeout(6000);
                    this.conn.setConnectTimeout(5000);
                    this.conn.setRequestMethod(HttpGet.METHOD_NAME);
                    this.conn.setDoOutput(true);
                    String stringBuilder;
                    try {
                        if (this.conn.getResponseCode() == HttpStatus.SC_OK) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(this.conn.getInputStream()));
                            StringBuilder result = new StringBuilder();
                            while (true) {
                                String line = reader.readLine();
                                if (line == null) {
                                    break;
                                }
                                result.append(line);
                            }
                            stringBuilder = result.toString();
                            return stringBuilder;
                        }
                        stringBuilder = "unsuccessful";
                        this.conn.disconnect();
                        return stringBuilder;
                    } catch (IOException e) {
                        e.printStackTrace();
                        stringBuilder = e.toString();
                    } finally {
                        this.conn.disconnect();
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                    return e1.toString();
                }
            } catch (MalformedURLException e2) {
                e2.printStackTrace();
                return e2.toString();
            }
        }

        protected void onPostExecute(String result) {
        }
    }

    public class AsyncRetrieve extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        ProgressDialog pdLoading = new ProgressDialog(login.this);
        String res;
        String f5u;
        URL url = null;

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... params) {
            try {
                this.url = new URL(this.f5u);
                try {
                    this.conn = (HttpURLConnection) this.url.openConnection();
                    this.conn.setReadTimeout(15000);
                    this.conn.setConnectTimeout(10000);
                    this.conn.setRequestMethod(HttpGet.METHOD_NAME);
                    this.conn.setDoOutput(true);
                    String stringBuilder;
                    try {
                        if (this.conn.getResponseCode() == HttpStatus.SC_OK) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(this.conn.getInputStream()));
                            StringBuilder result = new StringBuilder();
                            while (true) {
                                String line = reader.readLine();
                                if (line == null) {
                                    break;
                                }
                                result.append(line);
                            }
                            stringBuilder = result.toString();
                            return stringBuilder;
                        }
                        stringBuilder = "unsuccessful";
                        this.conn.disconnect();
                        return stringBuilder;
                    } catch (IOException e) {
                        e.printStackTrace();
                        stringBuilder = "Connection failed! ";
                    } finally {
                        this.conn.disconnect();
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                    return "Connection failed! ";
                }
            } catch (MalformedURLException e2) {
                e2.printStackTrace();
                return e2.toString();
            }
        }

        protected void onPostExecute(String result) {
            this.pdLoading.dismiss();
            SharedPreferences sharedpreferences = login.this.getSharedPreferences("mypref", 0);
            login.this.t2.setText(result.toString());
            sharedpreferences.edit().putString("id", result.toString());
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0186R.layout.activity_login);
        SharedPreferences sharedpreferences = getSharedPreferences("mypref", 0);
        this.f17t = (TextView) findViewById(C0186R.id.username);
        this.t2 = (TextView) findViewById(C0186R.id.uniqueid);
        this.f17t.setText("Welcome " + sharedpreferences.getString("username", ""));
        Builder builder = new Builder();
        builder.scheme("https").authority("aliadeel20.000webhostapp.com").appendPath("devicetracker").appendPath("response.php").appendQueryParameter("username", sharedpreferences.getString("username", "")).appendQueryParameter("password", sharedpreferences.getString("password", "")).appendQueryParameter("getid", "true");
        String myUrl = builder.build().toString();
        AsyncRetrieve as = new AsyncRetrieve();
        as.execute(new String[0]);
        as.f5u = myUrl;
        callAsynchronousTask();
    }

    private void checkGPSStatus() {
        LocationManager locationManager = null;
        boolean gps_enabled = false;
        boolean network_enabled = false;
        if (null == null) {
            locationManager = (LocationManager) getSystemService("location");
        }
        try {
            gps_enabled = locationManager.isProviderEnabled("gps");
        } catch (Exception e) {
        }
        try {
            network_enabled = locationManager.isProviderEnabled("network");
        } catch (Exception e2) {
        }
        if (!gps_enabled && !network_enabled) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setMessage("GPS not enabled");
            dialog.setPositiveButton("Ok", new C01871());
            dialog.create().show();
        }
    }

    public void callAsynchronousTask() {
        final Handler handler = new Handler();
        new Timer().schedule(new TimerTask() {

            class C01881 implements Runnable {
                C01881() {
                }

                public void run() {
                    try {
                        login.this.sendgps();
                    } catch (Exception e) {
                    }
                }
            }

            public void run() {
                handler.post(new C01881());
            }
        }, 0, 11000);
    }

    public void sendgps() {
        checkGPSStatus();
        if (!this.t2.getText().toString().isEmpty()) {
            String s = this.t2.getText().toString();
            AsyncRetrieve2 sa = new AsyncRetrieve2();
            Builder builder1 = new Builder();
            GPSTracker gps = new GPSTracker(this);
            builder1.scheme("https").authority("aliadeel20.000webhostapp.com").appendPath("devicetracker").appendPath("getgps.php").appendQueryParameter("deviceid", s).appendQueryParameter("latitude", String.valueOf(gps.getLatitude())).appendQueryParameter("longitude", String.valueOf(gps.getLongitude()));
            sa.f4u = builder1.build().toString();
            sa.execute(new String[0]);
        }
    }

    public void refresh(View v) {
        finish();
        startActivity(getIntent());
    }

    public void logout(View view) {
        Editor editor = getSharedPreferences("mypref", 0).edit();
        editor.clear();
        editor.commit();
        startActivity(new Intent(this, MainActivity.class));
    }
}
