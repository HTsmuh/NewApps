package com.example.madeel.devicetracker;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;

public class MainActivity extends AppCompatActivity {
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    public static final String mypreference = "mypref";
    EditText password;
    SharedPreferences sharedpreferences;
    TextView f16t;
    TextView textPHP;
    EditText username;

    private class AsyncRetrieve extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        ProgressDialog pdLoading;
        String res;
        String f3u;
        URL url;

        private AsyncRetrieve() {
            this.pdLoading = new ProgressDialog(MainActivity.this);
            this.url = null;
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pdLoading.setMessage("\tLoading..");
            this.pdLoading.setCancelable(false);
            this.pdLoading.show();
        }

        protected String doInBackground(String... params) {
            try {
                this.url = new URL(this.f3u);
                try {
                    this.conn = (HttpURLConnection) this.url.openConnection();
                    this.conn.setReadTimeout(15000);
                    this.conn.setConnectTimeout(10000);
                    this.conn.setRequestMethod(HttpGet.METHOD_NAME);
                    this.conn.setDoOutput(true);
                    String stringBuilder;
                    try {
                        if (this.conn.getResponseCode() == HttpStatus.SC_OK) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(this.conn.getInputStream()));
                            StringBuilder result = new StringBuilder();
                            while (true) {
                                String line = reader.readLine();
                                if (line == null) {
                                    break;
                                }
                                result.append(line);
                            }
                            stringBuilder = result.toString();
                            return stringBuilder;
                        }
                        stringBuilder = "unsuccessful";
                        this.conn.disconnect();
                        return stringBuilder;
                    } catch (IOException e) {
                        e.printStackTrace();
                        stringBuilder = e.toString();
                    } finally {
                        this.conn.disconnect();
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                    return e1.toString();
                }
            } catch (MalformedURLException e2) {
                e2.printStackTrace();
                return e2.toString();
            }
        }

        protected void onPostExecute(String result) {
            this.pdLoading.dismiss();
            result.trim();
            this.res = result.toString();
            String user = MainActivity.this.username.getText().toString();
            String pass = MainActivity.this.password.getText().toString();
            if (this.res.equalsIgnoreCase("Succeed")) {
                Toast.makeText(MainActivity.this, "Log In Succesfull!", 1).show();
                Editor editor = MainActivity.this.sharedpreferences.edit();
                editor.putString("username", user);
                editor.putString("password", pass);
                editor.commit();
                MainActivity.this.startActivity(new Intent(MainActivity.this, login.class));
            } else if (this.res.equalsIgnoreCase("fail")) {
                Toast.makeText(MainActivity.this, "Username or password is incorrect!", 1).show();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.sharedpreferences = getSharedPreferences("mypref", 0);
        if (!this.sharedpreferences.getString("username", "").isEmpty()) {
            startActivity(new Intent(this, login.class));
        }
        setContentView((int) C0186R.layout.activity_main);
        this.username = (EditText) findViewById(C0186R.id.editText);
        this.password = (EditText) findViewById(C0186R.id.editText2);
        this.textPHP = (TextView) findViewById(C0186R.id.txt);
    }

    public void adeelclick(View v) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://aliadeel20.000webhostapp.com/")));
    }

    public void onregclick(View v) {
        startActivity(new Intent(this, register.class));
    }

    public void onclickbtn(View v) {
        String user = this.username.getText().toString();
        String pass = this.password.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Fill all the fields!", 1).show();
            return;
        }
        Builder builder = new Builder();
        builder.scheme("https").authority("aliadeel20.000webhostapp.com").appendPath("devicetracker").appendPath("response.php").appendQueryParameter("username", user).appendQueryParameter("password", pass);
        String myUrl = builder.build().toString();
        AsyncRetrieve as = new AsyncRetrieve();
        as.execute(new String[0]);
        as.f3u = myUrl;
    }
}
