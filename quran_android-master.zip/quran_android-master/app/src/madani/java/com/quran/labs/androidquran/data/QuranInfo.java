package com.quran.labs.androidquran.data;

public class QuranInfo extends BaseQuranInfo {
}
