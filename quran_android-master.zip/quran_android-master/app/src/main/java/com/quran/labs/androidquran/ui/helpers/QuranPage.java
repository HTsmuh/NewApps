package com.quran.labs.androidquran.ui.helpers;

public interface QuranPage {
  void updateView();
  AyahTracker getAyahTracker();
}
