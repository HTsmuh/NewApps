package com.quran.labs.androidquran.di;

import javax.inject.Scope;

@Scope
public @interface ActivityScope {
}
